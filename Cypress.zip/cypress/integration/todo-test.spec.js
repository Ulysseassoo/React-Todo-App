// react-todo-test.js created with Cypress

import faker from "faker"

let randomTitle = faker.name.title()
let randomDescription = faker.lorem.text()

describe("TodoTest", () => {
	beforeEach(() => {
		let randomName = faker.name.findName()
		let randomEmail = faker.internet.email()
		let randomPassword = faker.internet.password()
		// Inscription to connect
		cy.visit("http://localhost:3000/")
		cy.get("[data-cy=username]").type(randomName)
		cy.get("[data-cy=email]").type(randomEmail)
		cy.get("[data-cy=password]").type(randomPassword)
		cy.get("[data-cy=confirmpassword]").type(randomPassword)
		cy.get("[data-cy=submit]").click()
	})

	it("add TODO item", () => {
		cy.createTODO(randomTitle, randomDescription)
		cy.get("[data-cy=todos]").children().should("have.length", 1)
	})

	it("add multiple TODOS", () => {
		var genArr = Array.from({ length: 10 }, (v, k) => k + 1)
		cy.wrap(genArr).each((index) => {
			cy.createTODO(randomTitle, randomDescription)
			cy.get("[data-cy=todos]").children().should("have.length", index)
		})
	})

	it("create a TODO & delete it >", () => {
		cy.createTODO(randomTitle, randomDescription)
		cy.get("[data-cy=todos]").children().get(".todo--item .todo--discard").click()
		cy.get("[data-cy=todos]").children().should("have.length", 0)
	})

	it("create a TODO & modify it >", () => {
		let newTitle = faker.name.title()
		let newDescription = faker.lorem.text()

		cy.createTODO(randomTitle, randomDescription)
		cy.get("[data-cy=todos]").children().should("have.length", 1)

		cy.get("[data-cy=todos]").children().get(".todo--item .todo--edit").click()
		cy.get("[data-cy=modal]").should("be.visible")
		cy.get("[data-cy=name]").type(newTitle)
		cy.get("[data-cy=description]").type(newDescription)
		cy.get("[data-cy=submit-modify]").click()
		cy.get("[data-cy=todo-title]").should("contain", newTitle)
	})
})
